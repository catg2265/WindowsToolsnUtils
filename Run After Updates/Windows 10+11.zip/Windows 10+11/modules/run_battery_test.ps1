function Get-BatteryInfo {
    Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
}

function Test-IsCharging {
    param([object]$Battery)
    return $Battery.BatteryStatus -eq 2  # 2 = charging
}

function Wait-ForUnplug {
    do {
        Start-Sleep -Seconds 2
        $battery = Get-BatteryInfo
    } while (Test-IsCharging $battery)
}

function Show-BatteryProgress {
    param(
        [int]$Current,
        [int]$Total,
        [object]$Progress
    )

    $percent = [int](($Current / $Total) * 100)
    $remainingSeconds = $Total - $Current
    $remainingMinutes = [int](($remainingSeconds % 3600) / 60)
    $remainingSec = $remainingSeconds % 60
    $timeLeft = "$remainingMinutes min $remainingSec sec"

    $Progress.Update.Invoke(
        "Battery Test Running",
        "Time remaining: $timeLeft",
        $percent
    )

    #Write-Progress `
    #    -Activity "Battery Test Running" `
    #    -Status "Time remaining: $timeLeft" `
    #    -PercentComplete $percent
}
function Get-Battery{

    $battery = Get-BatteryInfo
    $batteryExists = $false

    if ($null -ne $battery) { $batteryExists = $true }

    return [PSCustomObject]@{
        BatteryExists = $batteryExists
        Battery = $battery
    }
}

function Invoke-BatteryTest {
    param(
        [int]$DurationMinutes = 15,
        [string]$BatteryScriptPath,
        [pscustomobject]$batteryInfo,
        [object]$Progress
    )

    if (-not (Test-Path $BatteryScriptPath)) {
        throw "Battery script not found: $BatteryScriptPath"
    }

    Write-Host "Running battery test..."

    

    if ($batteryInfo.BatteryExists) {

        $charging = Test-IsCharging $batteryInfo.Battery

        if ($charging) {
            Write-Host ""
            Write-Host "Laptop is currently plugged into power."

            do {
                $choice = Read-Host "Do you want to skip the battery test? (Y/N)"

                if ($choice -match "^[Yy]$") {
                    Write-Host "Skipping battery test as requested."
                    return @{
                        BatteryResult  = "Skipped"
                        BatteryMinutes = 0
                    }
                }
                elseif ($choice -match "^[Nn]$") {
                    Write-Host "Please unplug the charger to continue..."
                    Wait-ForUnplug
                    Write-Host "Laptop is now on battery. Starting test..."
                    break
                }

            } while ($true)
        }

        # Run external battery script as a job
        $job = Start-Job -ScriptBlock {
            param($path, $duration)
        
            & $path -durationMinutes $duration
        } -ArgumentList $BatteryScriptPath, $DurationMinutes

        $durationSeconds = $DurationMinutes * 60

        $start = Get-Date
        $end   = $start.AddSeconds($durationSeconds)

        while ((Get-Date) -lt $end) {

            $remainingSeconds = [int]($end - (Get-Date)).TotalSeconds

            # clamp to avoid negative values at the end
            if ($remainingSeconds -lt 0) { $remainingSeconds = 0 }

            Show-BatteryProgress `
                -Current ($durationSeconds - $remainingSeconds) `
                -Total $durationSeconds `
                -Progress $Progress

            Start-Sleep -Seconds 1
        }

        Wait-Job $job
        $batteryMinutes = Receive-Job $job | Select-Object -Last 1
        Remove-Job $job

        # This completes progress bar
        $Progress.Complete.Invoke()
        #Write-Progress -Activity "Battery Test Running" -Completed -Status "Battery test complete"
    } else {
        Write-Host "No battery detected. Skipping battery test."
        return @{
            BatteryResult  = "No battery detected"
            BatteryHours = 0
            BatteryMinutes = 0
        }
    }

    $batteryHours = [int]($batteryMinutes / 60)

    return @{
        BatteryResult  = "$batteryHours timer"
        BatteryHours = $batteryHours
        BatteryMinutes = $batteryMinutes
    }
}