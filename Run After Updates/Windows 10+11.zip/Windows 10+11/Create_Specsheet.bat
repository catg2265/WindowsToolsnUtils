@echo off
echo Starting script...
powershell -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0main.ps1"
echo Script finished or crashed
pause